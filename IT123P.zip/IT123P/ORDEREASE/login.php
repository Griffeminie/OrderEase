<?php

include_once('connects.php');

$username = $_GET['uname'];
$password = $_GET['pword'];

$username = mysqli_real_escape_string($con, $username);
$password = mysqli_real_escape_string($con, $password);

$query = "SELECT id FROM users WHERE username='$username' AND password_hash='$password'";
$result = mysqli_query($con, $query);

if (!$result) {
    die('Error in SQL query: ' . mysqli_error($con));
}

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $user_id = $row['id'];
    echo "Success;" . $user_id; // Return "Success;" followed by the user id
} else {
    echo "failed";
}

mysqli_close($con);
?>
