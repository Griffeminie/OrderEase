<?php

include_once('connects.php'); // Ensure this file connects to your database

// Query to select id, name, price, description, restaurant_id, and restaurant name from foods and restaurants tables
$query = "
SELECT foods.id, foods.name, foods.price, foods.description, foods.restaurant_id, restaurants.name AS restaurant_name 
FROM foods 
JOIN restaurants ON foods.restaurant_id = restaurants.id";
$result = mysqli_query($con, $query);

if (!$result) {
    die('Error in SQL query: ' . mysqli_error($con));
}

$response = array();
while ($row = mysqli_fetch_assoc($result)) {
    $response[] = $row;
}

echo json_encode($response);

mysqli_close($con);
?>
