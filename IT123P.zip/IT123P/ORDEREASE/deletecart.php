<?php
// Include the database connection script
include 'connects.php';

// Check if 'id' parameter is set in GET request
if (isset($_GET['id'])) {
    // Retrieve ID parameter from GET request
    $id = $_GET['id'];

    // SQL statement to delete a row from 'cart' table
    $sql = "DELETE FROM cart WHERE id = ?";

    // Prepare statement
    $stmt = $con->prepare($sql);

    if ($stmt === false) {
        die('MySQL prepare error: ' . $con->error);
    }

    // Bind parameters
    $stmt->bind_param('i', $id); // Assuming 'id' is an integer in your database

    // Execute statement
    if ($stmt->execute()) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . $stmt->error;
    }

    // Close statement
    $stmt->close();
} else {
    echo "ID parameter is missing";
}

// Close connection
$con->close();
?>
