<?php
// Include database connection
include_once('connects.php');

// Get username, password, and email from GET parameters
$username = $_GET['uname'];
$password = $_GET['pword']; // Note: This is the plain text password
$email = $_GET['email'];

// Dummy values for created_at (replace with actual logic if needed)
$created_at = date('Y-m-d H:i:s'); // Current timestamp

// Escape values to prevent SQL injection
$username = mysqli_real_escape_string($con, $username);
$password = mysqli_real_escape_string($con, $password);
$email = mysqli_real_escape_string($con, $email);
$created_at = mysqli_real_escape_string($con, $created_at);

// Insert query
$query = "INSERT INTO users (username, password_hash, email, created_at) 
          VALUES ('$username', '$password', '$email', '$created_at')";

// Execute query
if (mysqli_query($con, $query)) {
    echo "Registration successful";
} else {
    echo "Error: " . mysqli_error($con);
}

// Close connection
mysqli_close($con);
?>

