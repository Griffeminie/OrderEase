<?php
// Include the database connection file
include 'connects.php';

// Check if the required parameters are set
if(isset($_GET['user_id']) && isset($_GET['food_id']) && isset($_GET['quantity']) && isset($_GET['restaurant_id'])) {
    // Get the parameters from the URL
    $user_id = $_GET['user_id'];
    $food_id = $_GET['food_id'];
    $quantity = $_GET['quantity'];
    $restaurant_id = $_GET['restaurant_id'];

    // Sanitize the inputs to prevent SQL injection
    $user_id = mysqli_real_escape_string($con, $user_id);
    $food_id = mysqli_real_escape_string($con, $food_id);
    $quantity = mysqli_real_escape_string($con, $quantity);
    $restaurant_id = mysqli_real_escape_string($con, $restaurant_id);

    // Prepare the SQL statement
    $sql = "INSERT INTO cart (user_id, food_id, quantity, restaurant_id, created_at) VALUES ('$user_id', '$food_id', '$quantity', '$restaurant_id', NOW())";

    // Execute the SQL statement
    if(mysqli_query($con, $sql)) {
        echo "Item added to cart successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($con);
    }
} else {
    echo "Missing required parameters.";
}

// Close the database connection
mysqli_close($con);
?>
