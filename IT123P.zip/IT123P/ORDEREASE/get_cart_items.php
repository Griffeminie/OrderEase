<?php
// Include database connection
include_once('connects.php');

// Get user_id from GET parameters
$user_id = $_GET['user_id'];

// Escape user_id to prevent SQL injection
$user_id = mysqli_real_escape_string($con, $user_id);

// SQL query to join cart, foods, and restaurants tables
$query = "
    SELECT c.id, c.user_id, f.name AS food_name, c.quantity, r.name AS restaurant_name, c.created_at
    FROM cart c
    JOIN foods f ON c.food_id = f.id
    JOIN restaurants r ON c.restaurant_id = r.id
    WHERE c.user_id = '$user_id';
";

// Execute query
$result = mysqli_query($con, $query);

// Check if query was successful
if ($result) {
    // Fetch all rows as an associative array
    $cart_items = mysqli_fetch_all($result, MYSQLI_ASSOC);

    // Output the result as JSON
    echo json_encode($cart_items);
} else {
    // Output an error message
    echo json_encode(["error" => "Failed to retrieve cart items: " . mysqli_error($con)]);
}

// Close the database connection
mysqli_close($con);
?>
