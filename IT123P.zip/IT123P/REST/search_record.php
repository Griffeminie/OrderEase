<?php

include_once('connects.php');

$name = $_GET['name'];

$query = "SELECT * FROM `studentdata` WHERE name LIKE '%$name%'";
$check = mysqli_query($con, $query);

if (!$check) {
    echo json_encode(["error" => mysqli_error($con)]);
    exit;
}

$myArray = array();
while ($row = mysqli_fetch_assoc($check)) {
    $myArray[] = [
        'name' => $row['name'],
        'school' => $row['school'],
        'country' => $row['country'],
        'gender' => (string)$row['gender'], // Cast gender to string
    ];
}

echo json_encode($myArray);

?>
